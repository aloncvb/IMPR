from . import sol5_utils
import numpy as np
import matplotlib.pyplot as plt
from random import shuffle, sample, uniform
from scipy.ndimage.filters import convolve
from math import pi

# my imports:
import tensorflow
# keras imports:
from tensorflow.keras.layers import Conv2D, Activation, Input, Add
from tensorflow.keras import Model
from tensorflow.keras.optimizers import Adam
from scipy.misc import imread
from skimage.color import rgb2gray


cache = {}
PERCENT = 0.8


# code from ex1 as requested in the ex5 description
def read_image(filename, representation):
    img = imread(filename)
    if representation == 1:
        if len(img.shape) > 2:
            im_float = rgb2gray(img)
            return im_float.astype(np.float64)

    im_float = img.astype(np.float64)
    im_float /= 255
    return im_float.astype(np.float64)


def add_gaussian_noise(image, min_sigma, max_sigma):
    sigma = uniform(min_sigma, max_sigma)
    mat = np.random.normal(0, sigma, size=image.shape)
    image += mat
    return ((np.round(255*image))/255).clip(0, 1)


def get_patch(im, crop_size, corrupt_im=None):
    im_width = im.shape[0]
    im_height = im.shape[1]
    crop_width = crop_size[0]
    crop_height = crop_size[1]
    x = np.random.randint(0, im_width - crop_width, dtype=np.int)
    y = np.random.randint(0, im_height - crop_height, dtype=np.int)
    if corrupt_im is None:
        return im[x:x + crop_width, y: y + crop_height]
    return im[x:x + crop_width, y: y + crop_height], corrupt_im[x:x + crop_width, y: y + crop_height]


def load_dataset(filenames, batch_size, corruption_func, crop_size):
    while True:
        # adding to dictionary and read relevant images
        names = np.random.choice(filenames, batch_size, True)
        images = []
        for name in names:
            if name in cache.keys():
                images.append(cache[name])
            else:
                images.append(read_image(name, 1))
        cache.update(list(zip(names, images)))

        # creating the patches
        source_batch, target_batch = [], []
        for im in images:
            patch = get_patch(im, (3*crop_size[0], 3*crop_size[1]))  # 3 taken from ex5 description
            corrupt_patch = corruption_func(patch.copy())
            patch, corrupt_patch = get_patch(patch, crop_size, corrupt_patch)
            source_batch.append(corrupt_patch - 0.5)
            target_batch.append(patch - 0.5)
        source_batch = np.stack(source_batch)
        target_batch = np.stack(target_batch)
        source_batch = source_batch.reshape((batch_size, crop_size[0], crop_size[1], 1))
        target_batch = target_batch.reshape((batch_size, crop_size[0], crop_size[1], 1))
        yield (source_batch, target_batch)


def resblock(input_tensor, num_channels):
    layer = Conv2D(num_channels, (3, 3), padding="same")(input_tensor)
    layer = Activation("relu")(layer)
    layer = Conv2D(num_channels, (3, 3), padding="same")(layer)
    layer = Add()([layer, input_tensor])
    layer = Activation("relu")(layer)
    return layer


def build_nn_model(height, width, num_channels, num_res_blocks):
    first_input = Input(shape=(height, width, 1))
    input_tensor = first_input
    input_tensor = Conv2D(num_channels, (3, 3), padding="same")(input_tensor)
    input_tensor = Activation("relu")(input_tensor)
    for i in range(num_res_blocks):
        input_tensor = resblock(input_tensor, num_channels)
    out = Conv2D(1, (3, 3), padding="same")(input_tensor)  # 1 because last conv layer
    out = Add()([first_input, out])
    return Model(inputs=first_input, outputs=out)


def train_model(model, images, corruption_func, batch_size, steps_per_epoch, num_epochs, num_valid_samples):
    shuffle(images)
    split = int(PERCENT * len(images))
    training = images[:split]
    validation = images[split:]
    train_dataset = load_dataset(training, batch_size, corruption_func, model.input_shape[1:3])
    val_dataset = load_dataset(validation, batch_size, corruption_func, model.input_shape[1:3])
    model.compile(loss="mean_squared_error", optimizer=Adam(beta_2=0.9))
    model.fit_generator(train_dataset, steps_per_epoch, num_epochs, validation_data=val_dataset,
                        validation_steps=num_valid_samples/batch_size)


def restore_image(corrupted_image, base_model):
    corrupted_image = corrupted_image.copy()
    corrupted_image -= 0.5
    a = Input(shape=(corrupted_image.shape[0], corrupted_image.shape[1], 1))
    b = base_model(a)
    new_model = Model(inputs=a, outputs=b)
    predict_im = new_model.predict(corrupted_image.reshape((1, corrupted_image.shape[0],
                                                            corrupted_image.shape[1], 1)))
    predict_im = predict_im.reshape((corrupted_image.shape[0], corrupted_image.shape[1]))
    predict_im += 0.5
    return (np.clip(predict_im, 0, 1)).astype(np.float64)


def learn_denoising_model(num_res_blocks=5, quick_mode=False):
    file_names = sol5_utils.images_for_denoising()
    model = build_nn_model(24, 24, 48, num_res_blocks)
    corruption_func = lambda im: add_gaussian_noise(im, 0, 0.2)
    if quick_mode:
        train_model(model, file_names, corruption_func, 10, 3, 2, 30)
    else:
        train_model(model, file_names, corruption_func, 100, 100, 5, 1000)
    return model


def add_motion_blur(image, kernel_size, angle):
    motion_kernel = sol5_utils.motion_blur_kernel(kernel_size, angle)
    corrupted_im = convolve(image, motion_kernel)
    return (np.round(corrupted_im * 255)/255).clip(0, 1)


def random_motion_blur(image, list_of_kernel_sizes):
    angle = uniform(0, 1) * pi
    kernel_size = sample(list_of_kernel_sizes, 1)[0]
    motion_kernel = sol5_utils.motion_blur_kernel(kernel_size, angle)
    corrupted_im = convolve(image, motion_kernel)
    return (np.round(corrupted_im * 255) / 255).clip(0, 1)


def learn_deblurring_model(num_res_blocks=5, quick_mode=False):
    filenames = sol5_utils.images_for_deblurring()
    model = build_nn_model(16, 16, 32, num_res_blocks)
    corruption_func = lambda im: random_motion_blur(im, [7])
    if quick_mode:
        train_model(model, filenames, corruption_func, 10, 3, 2, 30)
    else:
        train_model(model, filenames, corruption_func, 100, 100, 10, 1000)
    return model


def create_graphs():
    denoise_loss = []
    deblurr_loss = []
    for i in range(1, 6):
        model1 = learn_denoising_model(i, False)
        model2 = learn_deblurring_model(i, False)
        denoise_loss.append(model1.history.history['val_loss'][-1])
        deblurr_loss.append(model2.history.history['val_loss'][-1])
    plt.plot([1, 2, 3, 4, 5], denoise_loss)
    plt.ylabel("valid_loss")
    plt.xlabel("depth of resblock")
    plt.show()
    plt.plot([1, 2, 3, 4, 5], deblurr_loss)
    plt.ylabel("valid_loss")
    plt.xlabel("depth of resblock")
    plt.show()

