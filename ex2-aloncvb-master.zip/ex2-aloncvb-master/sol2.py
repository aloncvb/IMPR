import numpy as np
import math
from scipy.signal import convolve2d
from scipy.misc import imread
import matplotlib.pyplot as plt
from skimage.color import rgb2gray


# code from ex1 as requested in the ex2 description
def read_image(filename, representation):
    img = imread(filename)
    if representation == 1:
        if len(img.shape) > 2:
            im_float = rgb2gray(img)
            return im_float

    im_float = img.astype(np.float64)
    im_float /= 255
    return im_float


def dft(n):
    omega = np.exp(-2j*np.pi/n)  # = e^-2(pi)i/n
    i, j = np.meshgrid(np.arange(n), np.arange(n))
    dft_matrix = np.power(omega, i*j)
    return dft_matrix.astype(np.complex128)


def DFT(signal):
    n = signal.shape[0]
    matrix = dft(n)
    return np.dot(matrix, signal)


def IDFT(fourier_signal):
    n = fourier_signal.shape[0]
    matrix = np.linalg.inv(dft(n))
    return np.dot(matrix, fourier_signal)


def DFT2(image):
    sum_matrix = DFT(image).astype(np.complex128)
    sum_matrix = np.transpose(sum_matrix)
    sum_matrix = DFT(sum_matrix)
    return np.transpose(sum_matrix)


def IDFT2(fourier_image):
    sum_matrix = IDFT(fourier_image)
    sum_matrix = np.transpose(sum_matrix)
    sum_matrix = IDFT(sum_matrix)
    return np.transpose(sum_matrix)


def conv_der(im):
    vec = [[-1, 0, 1]]
    dx = convolve2d(im, vec, "same").astype(np.float64)
    dy = convolve2d(im, np.transpose(vec), "same").astype(np.float64)
    magnitude = np.sqrt(np.abs(dx)**2 + np.abs(dy)**2)
    return magnitude


def fourier_der(im):
    n = im.shape[0]
    m = im.shape[1]
    dx = DFT2(im) * (2j*math.pi) / n
    dy = DFT2(im) * (2j*math.pi) / m

    dx = np.fft.fftshift(dx)
    for i in range(n):
        dx[i] = dx[i] * (-n/2 + i)
    dx = np.real(IDFT2(dx))

    dy = np.transpose(dy)
    dy = np.fft.fftshift(dy)
    for i in range(m):
        dy[i] = dy[i] * (-n/2 + i)

    dy = np.transpose(dy)
    dy = np.real(IDFT2(dy))

    magnitude = np.sqrt(np.abs(dx)**2 + np.abs(dy)**2)
    return np.real(magnitude).astype(np.float64)


def get_gau_kernel(kernel_size):
    vec = np.array([1, 1]).astype(np.float64)
    while len(vec) < kernel_size:
        vec = np.convolve(vec, [1, 1])
    gau_ker = np.outer(vec, vec).astype(np.float64)
    gau_ker /= np.sum(gau_ker)
    return gau_ker


def blur_spatial(im, kernel_size):
    #  just in case
    if kernel_size == 1:
        return im

    gau_ker = get_gau_kernel(kernel_size)
    return convolve2d(im, gau_ker, "same")


def blur_fourier(im, kernel_size):
    #  just in case
    if kernel_size == 1:
        return im
    fourier_im = DFT2(im)
    center_x = math.floor(im.shape[0]/2) - math.floor(kernel_size/2)
    center_y = math.floor(im.shape[1]/2) - math.floor(kernel_size/2)
    gau_ker = get_gau_kernel(kernel_size)
    if im.shape[0] % 2 == 0:
        x_pad = (center_x, center_x - 1)
    else:
        x_pad = (center_x, center_x)
    if im.shape[1] % 2 == 0:
        y_pad = (center_y, center_y - 1)
    else:
        y_pad = (center_y, center_y)

    gau_ker = np.pad(gau_ker, (x_pad, y_pad), "constant")  # pad
    fourier_gau_ker = DFT2(gau_ker)
    fourier_im = fourier_im * fourier_gau_ker
    return np.fft.ifftshift(np.real(IDFT2(fourier_im)))



