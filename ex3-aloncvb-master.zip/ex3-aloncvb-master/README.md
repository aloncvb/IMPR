aloncvb
sol3.py
answer_q1.txt
answer_q2.txt
answer_q3.txt
README.md
images/beach.jpg
images/beach mask.jpg
images/gusta face.jpg
images/space.jpg
images/Teletubbies.jpg
images/Teletubbies mask.jpg