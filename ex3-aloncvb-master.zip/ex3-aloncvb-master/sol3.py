import numpy as np
from scipy.misc import imread
import matplotlib.pyplot as plt
from skimage.color import rgb2gray
import os
from scipy.ndimage.filters import convolve


# code from ex1 as requested in the ex2 description
def read_image(filename, representation):
    img = imread(filename)
    if representation == 1:
        if len(img.shape) > 2:
            im_float = rgb2gray(img)
            return im_float.astype(np.float64)

    im_float = img.astype(np.float64)
    im_float /= 255
    return im_float.astype(np.float64)


#  kernel_size is odd number
#  copied from my ex2
def get_filter_vec(kernel_size):
    if kernel_size == 1:
        return np.array([1]).astype(np.float64)
    vec = np.array([1, 1]).astype(np.float64)
    while len(vec) < kernel_size:
        vec = np.convolve(vec, [1, 1])
    # gau_ker = np.outer(vec, vec).astype(np.float64)
    gau_ker = vec / np.sum(vec)  # normalize the kernel
    return gau_ker.astype(np.float64)


#  im - gray img values are double in range [0,1]
#  filter_size - an int, *odd* number, size of normalized kernel
#  max_levels
def build_gaussian_pyramid(im, max_levels, filter_size):
    filter_vec = get_filter_vec(filter_size)
    filter_vec = filter_vec.reshape((1, len(filter_vec)))
    pyr = [im.copy()]
    counter = 1
    img = im.copy()
    while counter < max_levels and img.shape[0] >= 32 and img.shape[1] >= 32:
        # blur the image
        img = convolve(img, filter_vec)
        img = convolve(img, np.transpose(filter_vec))

        # take every second pixel of blurred image
        img = img[0::2, 0::2]
        # add the smaller image
        pyr.append(img.copy())
        counter += 1
    return pyr, filter_vec


# expand_to_shape is the shape im will expand to.
# im is the image to expand
def expand(im, filter_vec, expand_to_shape):
    # expand the image
    expand_im = np.zeros(expand_to_shape)
    expand_im[1::2, 1::2] = im

    # blur the image
    expand_im = convolve(expand_im, 2 * filter_vec)
    expand_im = convolve(expand_im, np.transpose(2 * filter_vec))
    return expand_im


#  im - gray img values are double in range [0,1]
#  filter_size - an int, *odd* number, size of normalized kernel
#  max_levels
def build_laplacian_pyramid(im, max_levels, filter_size):
    lap_pyr = []
    gau_pyr, filter_vec = build_gaussian_pyramid(im, max_levels, filter_size)
    for i in range(1, len(gau_pyr)):  # loop over max_levels (at most)
        # expand the image
        img = expand(gau_pyr[i], filter_vec, gau_pyr[i - 1].shape)

        # G[i - 1] - expand(G[i]
        img = gau_pyr[i - 1] - img
        lap_pyr.append(img.copy())
    lap_pyr.append(gau_pyr[-1])  # add the last one
    return lap_pyr, filter_vec


def laplacian_to_image(lpyr, filter_vec, coeff):
    img = coeff[-1] * lpyr[-1]
    for i in range(len(lpyr) - 2, -1, -1):
        img = expand(img, filter_vec, lpyr[i].shape)
        img += coeff[i] * lpyr[i]
    return img


def normalize_im(img):
    min_val = np.amin(img)
    max_val = np.amax(img)
    img = (img - min_val) / (max_val - min_val)
    return img


def render_pyramid(pyr, levels):
    width = 0
    height = pyr[0].shape[0]
    for i in range(levels):
        width += pyr[i].shape[1]
    res = np.zeros((height, width)).astype(np.float64)
    bef_width = 0
    for i in range(levels):
        im = pyr[i].copy()
        height = im.shape[0]
        im_width_end = bef_width + im.shape[1]
        im = normalize_im(im)
        res[:height, bef_width:im_width_end] = im
        bef_width += im.shape[1]
    return res


def display_pyramid(pyr, levels):
    res = render_pyramid(pyr, levels)
    plt.imshow(res, cmap="gray")
    plt.show()
    return


def pyramid_blending(im1, im2, mask, max_levels, filter_size_im, filter_size_mask):
    mask = np.array(mask).astype(bool)
    l1_pyr, vec1 = build_laplacian_pyramid(im1, max_levels, filter_size_im)
    l2_pyr, vec2 = build_laplacian_pyramid(im2, max_levels, filter_size_im)
    mask_g_pyr, mask_vec = build_gaussian_pyramid(mask.astype(np.float64), max_levels, filter_size_mask)
    iters = min(len(mask_g_pyr), len(l1_pyr), len(l2_pyr))
    l_out = []
    for k in range(iters):
        im = (mask_g_pyr[k] * l1_pyr[k]) + ((1 - mask_g_pyr[k]) * l2_pyr[k])
        l_out.append(im)
    coeff = np.ones(len(l_out))
    im_blend = laplacian_to_image(l_out, vec1, coeff)
    im_blend = normalize_im(im_blend)
    return im_blend


def relpath(filename):
    return os.path.join(os.path.dirname(__file__), filename)


def blend_example_n(im1_name, im2_name, mask_name):
    im1 = read_image(relpath(im1_name), 0)
    im2 = read_image(relpath(im2_name), 0)
    mask = read_image(relpath(mask_name), 0).astype(bool)
    blend = im2.copy().astype(np.float64)
    for i in range(3):
        blend[:, :, i] = pyramid_blending(im1[:, :, i], im2[:, :, i], mask[:, :, i], 5, 21, 21)

    plt.figure()
    plt.imshow(im1)
    plt.figure()
    plt.imshow(im2)
    plt.figure()
    plt.imshow(mask.astype(np.float64))
    plt.figure()
    plt.imshow(blend)
    plt.show()

    return im1, im2, mask, blend


def blending_example1():
    return blend_example_n("images/gusta face.jpg", "images/Teletubbies.jpg", "images/Teletubbies mask.jpg")


def blending_example2():
    return blend_example_n("images/space.jpg", "images/beach.jpg", "images/beach mask.jpg")






