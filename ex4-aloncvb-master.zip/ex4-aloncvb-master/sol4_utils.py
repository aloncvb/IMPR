import numpy as np
from scipy.misc import imread
import matplotlib.pyplot as plt
from skimage.color import rgb2gray
from scipy.ndimage.filters import convolve
from scipy.signal import convolve2d


# code from ex1 as requested in the ex2 description
def read_image(filename, representation):
    img = imread(filename)
    if representation == 1:
        if len(img.shape) > 2:
            im_float = rgb2gray(img)
            return im_float.astype(np.float64)

    im_float = img.astype(np.float64)
    im_float /= 255
    return im_float.astype(np.float64)


#  kernel_size is odd number
#  copied from my ex2
def get_filter_vec(kernel_size):
    if kernel_size == 1:
        return np.array([1]).astype(np.float64)
    vec = np.array([1, 1]).astype(np.float64)
    while len(vec) < kernel_size:
        vec = np.convolve(vec, [1, 1])
    # gau_ker = np.outer(vec, vec).astype(np.float64)
    gau_ker = vec / np.sum(vec)  # normalize the kernel
    return gau_ker.astype(np.float64)


#  im - gray img values are double in range [0,1]
#  filter_size - an int, *odd* number, size of normalized kernel
#  max_levels
def build_gaussian_pyramid(im, max_levels, filter_size):
    filter_vec = get_filter_vec(filter_size)
    filter_vec = filter_vec.reshape((1, len(filter_vec)))
    pyr = [im.copy()]
    counter = 1
    img = im.copy()
    while counter < max_levels and img.shape[0] >= 32 and img.shape[1] >= 32:
        # blur the image
        img = convolve(img, filter_vec)
        img = convolve(img, np.transpose(filter_vec))

        # take every second pixel of blurred image
        img = img[0::2, 0::2]
        # add the smaller image
        pyr.append(img.copy())
        counter += 1
    return pyr, filter_vec


def get_gau_kernel(kernel_size):
    vec = np.array([1, 1]).astype(np.float64)
    while len(vec) < kernel_size:
        vec = np.convolve(vec, [1, 1])
    gau_ker = np.outer(vec, vec).astype(np.float64)
    gau_ker /= np.sum(gau_ker)
    return gau_ker


def blur_spatial(im, kernel_size):
    #  just in case
    if kernel_size == 1:
        return im

    gau_ker = get_gau_kernel(kernel_size)
    return convolve2d(im, gau_ker, "same")



