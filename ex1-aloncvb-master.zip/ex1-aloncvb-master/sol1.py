import numpy as np
from skimage.color import rgb2gray
from scipy.misc import imread
import matplotlib.pyplot as plt


BINS_SIZE = 256
MAX_GRAY_VALUE = 255
LAST_IN_ARRAY = -1


def read_image(filename, representation):
    img = imread(filename)
    if representation == 1:
        if len(img.shape) > 2:
            im_float = rgb2gray(img)
            return im_float

    im_float = img.astype(np.float64)
    im_float /= 255
    return im_float


def imdisplay(filename, representation):
    im = read_image(filename, representation)
    if representation == 1:
        plt.imshow(im, cmap="gray")
        plt.show()
    else:
        plt.imshow(im)
        plt.show()


def rgb2yiq(imRGB):
    matrix = np.array([0.299, 0.587, 0.114, 0.596, -0.275, -0.321, 0.212, -0.523, 0.311]).reshape((3, 3))
    imYIQ = np.tensordot(imRGB, matrix, axes=(-1, -1))
    return imYIQ


def yiq2rgb(imYIQ):
    matrix = np.array([0.299, 0.587, 0.114, 0.596, -0.275, -0.321, 0.212, -0.523, 0.311]).reshape((3, 3))  # our matrix
    inv_matrix = np.linalg.inv(matrix)
    imRGB = np.tensordot(imYIQ, inv_matrix, axes=(-1, -1))  # tensordot multiply matrices with 3 dims
    return imRGB


def histogram_equalize(im_orig):
    im_eq = im_orig.copy()
    is_rgb = False
    if len(im_orig.shape) > 2:  # means RGB picture
        imYIQ = rgb2yiq(im_eq)
        im_eq = imYIQ[:, :, 0]  # takes just the Y layer
        is_rgb = True

    hist, bins = np.histogram(im_eq.flatten(), BINS_SIZE, density=True)
    cum_histogram = np.cumsum(hist)
    pixel_num = cum_histogram[LAST_IN_ARRAY]
    cum_histogram = (cum_histogram / pixel_num) * MAX_GRAY_VALUE  # normalize
    if np.amin(cum_histogram) < 0 or np.amax(cum_histogram) > MAX_GRAY_VALUE:
        first_not_zero = int(np.nonzero(cum_histogram)[0][0])
        cum_histogram = (cum_histogram - cum_histogram[first_not_zero]) / \
                        (cum_histogram[LAST_IN_ARRAY] - cum_histogram[first_not_zero])*255
    cum_histogram = np.round(cum_histogram)
    im_eq = np.interp(im_eq, bins[:-1], cum_histogram)
    if is_rgb:
        imYIQ[:, :, 0] = im_eq
        im_eq = yiq2rgb(imYIQ)
    hist_eq, bins_eq = np.histogram(im_eq.flatten(), BINS_SIZE)
    return [im_eq, hist, hist_eq]


def get_segments(hist, n_quant):
    hist_sum = np.cumsum(hist)
    end = hist_sum[LAST_IN_ARRAY]
    start = hist_sum[LAST_IN_ARRAY]/n_quant
    float_segments = np.linspace(start, end, n_quant)  # returns array of floats with jumps of 256/n_quant
    hist_sum = np.cumsum(hist)
    # take the max pixel from the segments we created
    z = [np.amax(np.where(hist_sum <= float_segments[i])) for i in range(n_quant)]
    z = [0] + z
    if z[-1] != 255:
        z.append(255)
    return z


def quantize(im_orig, n_quant, n_iter):
    im_quant = im_orig.copy()
    is_rgb = False
    if len(im_orig.shape) > 2:  # means RGB picture
        imYIQ = rgb2yiq(im_quant)
        im_quant = imYIQ[:, :, 0]  # takes just the Y layer
        is_rgb = True

    hist, bins = np.histogram(im_quant, BINS_SIZE, density=True)

    z = get_segments(hist, n_quant)
    q = np.array([0 for i in range(n_quant)]).astype(np.float64)
    iter = 0
    converge = False
    error = []
    while iter < n_iter and (not converge):

        for i in range(len(q)):
            lower = 0
            upper = 0
            for g in range(z[i], z[i + 1] + 1):
                upper += g * hist[g]
                lower += hist[g]
            if lower == 0:
                q[i] = 0
            else:
                q[i] = upper / lower
        q = (np.round(q)).astype(int)

        # calculate error
        error_sum = 0
        for i in range(len(q)):
            for g in range(z[i], z[i + 1] + 1):
                error_sum += (q[i] - g)**2 * hist[g]

        counter = 2  # because at z[0],z[k] the values stay the same
        for i in range(1, n_quant):
            z_last = z[i]
            z[i] = (np.ceil((q[i - 1] + q[i]) / 2)).astype(int)
            if z_last == z[i]:
                counter += 1
        if counter == len(z):
            converge = True
        else:
            error.append(error_sum)
        iter += 1

    im_shape = im_quant.shape
    im_quant = im_quant.flatten()*255
    im_copy = im_quant.copy()
    for i in range(1, len(z)):
        im_quant[im_copy <= z[i]] = q[i - 1]
        im_copy[im_copy <= z[i]] = 256
    im_quant = im_quant.reshape(im_shape) / 255

    if is_rgb:
        imYIQ[:, :, 0] = im_quant
        im_quant = yiq2rgb(imYIQ)

    return [im_quant, error]

