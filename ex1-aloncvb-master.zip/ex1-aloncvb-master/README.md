aloncvb
sol1.py
answer_q1.txt
README.md